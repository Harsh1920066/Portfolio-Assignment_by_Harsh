import logo from './logo.svg';
import React from "react";
import ReactDom from "react-dom";
import './App.css';

function App() {
  return (
    <div class="content">
    <h4>Portfolio Template</h4>
 

    <h2><span>Name:</span>Abc</h2>
      <h2><span>Projects</span></h2>
     
    <ul class="li"> <li >Project Name</li></ul>
    <ul class="li2">
       <li>Tech used :<span>Laravel(PHP),Bootstrap</span></li>
       <li> No. of Team Members:<span>4</span></li>
       <li>Purpose of project:<span> It was meant for college students,to automate the existing library</span></li>
       <li>Your role in the project:<span>Front End Design</span></li>
       <li>Duration of the project:<span>01/01/2020 - 12/03/2020</span></li>
       <li>GitHub Link:<span> https:www.github.com</span></li>
       <li>Website:<span> https:www.google.com</span></li>



    </ul >
       <h2><span>Skills with Level</span></h2>
      <ul class="li3" >
      <li > C/C++ -Expert</li>
       <li >Data Structure -Intermediate</li>
      </ul>
      <h2><span>Courses and Certificates</span></h2>
      <ul class="li4">
      <li >Easy toAdvanced Data Structure -Udemy</li>
       <li >Project management professional (PMP)</li>
      </ul >
      <h2><span>Subjects of Interest</span></h2>
      <ul class="li5">
      <li > Data Structure</li>
       <li > Web Development</li>
      </ul>
      <h2><span>Academics</span></h2>
      <ul class="li6">
        <li>MCA -2021-88%</li>
        <li>BCA -2020-77%</li>
        <li>12th -2017-90%</li>
      </ul>
 </div>
 
   
  );
}

export default App;
